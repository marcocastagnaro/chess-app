package root.common.Enums;

public enum Pieces {
    PAWN, ROOK, KNIGHT, BISHOP, QUEEN, KING, CHANCELLOR, ARCHBISHOP
}
