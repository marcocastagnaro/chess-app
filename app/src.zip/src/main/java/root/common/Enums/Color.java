package root.common.Enums;

public enum Color {
    BLACK, WHITE, BlUE, RED
}
